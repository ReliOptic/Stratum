% STRATUM DETERMINISTIC THERMAL AUDIT SCRIPT
% NOTE: Agreement between Simulink and expected_results.csv proves the
% numerical implementation of the lumped-RC ODE, NOT the physical reality.
% Uses core MATLAB and Simulink State-Space blocks only (no Simscape).
function run_stratum_experiment(headless)
    if nargin < 1, headless = strcmpi(getenv('STRATUM_HEADLESS'), '1') || strcmpi(getenv('STRATUM_HEADLESS'), 'true'); end
    vis = "on"; if headless, vis = "off"; end
    params = readtable('parameters.csv', 'TextType', 'string');
    scenario = readtable('stress_scenario_timeseries.csv', 'PreserveVariableNames', true);
    expected = readtable('expected_results.csv', 'TextType', 'string');
    bman_lines = string(readlines('bundle_manifest.txt'));
    run_id = extract_kv(bman_lines, "run_id"); bundle_sha256 = extract_kv(bman_lines, "bundle_sha256");
    revs = [0, 1]; all_rows = table();
    fig = figure('Visible', char(vis)); hold on;
    for r_idx = 1:length(revs)
        rev = revs(r_idx); sub = params(params.revision == rev, :);
        rev_rows = simulate_revision(rev, sub, scenario);
        all_rows = [all_rows; rev_rows]; %#ok<AGROW>
        storage_ids = string(sub.part_id(sub.role == "energy_storage"));
        for s_idx = 1:length(storage_ids)
            sid = storage_ids(s_idx); mask = rev_rows.node_id == sid;
            lbl = "V" + string(rev) + " · " + sid + " (storage)";
            plot(rev_rows.time_s(mask), rev_rows.temp_C(mask), 'LineWidth', 2.0, 'DisplayName', char(lbl));
        end
    end
    xlabel('Time (s)', 'Interpreter', 'none'); ylabel('Temperature (C)', 'Interpreter', 'none');
    title('Stratum Simulink State-Space Thermal Audit', 'Interpreter', 'none');
    legend('show', 'Location', 'best', 'Interpreter', 'none'); grid on; drawnow; saveas(fig, 'results.png');
    if vis == "off", close(fig); end
    writetable(all_rows, 'results.csv');
    write_audit_and_manifest(all_rows, expected, params, run_id, bundle_sha256);
    disp('Next: attach agent_handoff_spec.txt in Copilot Chat and paste copilot_prompt.txt');
end

function rows = simulate_revision(rev, sub, scenario)
    n = height(sub); C = sub.mass_g .* sub.cp_J_per_gK; L = diag(sub.g_amb_W_per_K);
    for i = 1:n
        edges_str = strtrim(string(sub.conductance_edges(i)));
        if strlength(edges_str) > 0 && edges_str ~= "none"
            parts = split(edges_str, ";");
            for p_idx = 1:length(parts)
                kv = split(parts(p_idx), ":");
                if length(kv) == 2
                    j = find(string(sub.part_id) == kv(1), 1); g_ij = str2double(kv(2));
                    if ~isempty(j) && i ~= j, L(i, i) = L(i, i) + g_ij; L(i, j) = L(i, j) - g_ij; end
                end
            end
        end
    end
    A = -diag(1 ./ C) * L; B = diag(1 ./ C);
    t_vec = scenario.time_s; T_amb = scenario.ambient_C(1); U = zeros(length(t_vec), n);
    for i = 1:n
        col_name = char("power_" + string(sub.part_id(i)) + "_W");
        if ismember(col_name, scenario.Properties.VariableNames), U(:, i) = scenario.(col_name);
        else, U(:, i) = sub.heat_W(i); end
    end
    mdl = char("stratum_rev" + string(rev));
    q_blk = char(string(mdl) + "/Q_in"); ss_blk = char(string(mdl) + "/RC_StateSpace"); th_blk = char(string(mdl) + "/Theta_out");
    if bdIsLoaded(mdl), close_system(mdl, 0); end
    new_system(mdl);
    add_block('simulink/Sources/From Workspace', q_blk);
    add_block('simulink/Continuous/State-Space', ss_blk);
    add_block('simulink/Sinks/To Workspace', th_blk);
    set_param(q_blk, 'VariableName', 'sim_u');
    set_param(ss_blk, 'A', mat2str(A), 'B', mat2str(B), 'C', mat2str(eye(n)), 'D', mat2str(zeros(n, n)), 'X0', mat2str(zeros(n, 1)));
    set_param(th_blk, 'VariableName', 'theta_out', 'SaveFormat', 'Array');
    add_line(mdl, 'Q_in/1', 'RC_StateSpace/1'); add_line(mdl, 'RC_StateSpace/1', 'Theta_out/1');
    save_system(mdl, char(string(mdl) + ".slx"));
    sim_in = Simulink.SimulationInput(mdl);
    sim_in = sim_in.setVariable('sim_u', [t_vec, U]);
    sim_in = sim_in.setModelParameter('StopTime', num2str(max(t_vec)), 'SolverType', 'Fixed-step', 'Solver', 'ode14x', 'FixedStep', '1.0');
    sim_out = sim(sim_in); theta = sim_out.get('theta_out'); close_system(mdl, 0);
    rows = table();
    for k = 1:length(t_vec)
        for i = 1:n
            row = table(t_vec(k), rev, string(sub.part_id(i)), round(T_amb + theta(k, i), 4), ...
                'VariableNames', {'time_s', 'revision', 'node_id', 'temp_C'});
            rows = [rows; row]; %#ok<AGROW>
        end
    end
end

function write_audit_and_manifest(actual, expected, params, run_id, b_sha)
    storage_ids = unique(string(params.part_id(params.role == "energy_storage")));
    if isempty(storage_ids), storage_ids = unique(string(params.part_id)); end
    max_diff = 0.0; worst_t = 0.0;
    for i = 1:height(expected)
        if ismember(string(expected.node_id(i)), storage_ids)
            m = actual.revision == expected.revision(i) & string(actual.node_id) == string(expected.node_id(i)) ...
                & abs(actual.time_s - expected.time_s(i)) < 1e-6;
            if any(m)
                d = abs(actual.temp_C(find(m, 1)) - expected.temp_C(i));
                if d > max_diff, max_diff = d; worst_t = expected.time_s(i); end
            end
        end
    end
    if max_diff <= 0.5
        line = string(sprintf('AUDIT: MATCH (max |dT| = %.2f C)', double(max_diff)));
    else
        line = string(sprintf('AUDIT: MISMATCH (max |dT| = %.2f C at t = %.1f s)', double(max_diff), double(worst_t)));
    end
    disp(line); writelines(line, 'audit.txt');
    ts = string(datetime('now', 'TimeZone', 'UTC', 'Format', 'yyyy-MM-dd''T''HH:mm:ss''Z'''));
    man = ["run_id=" + string(run_id); "bundle_sha256=" + string(b_sha); ...
           "matlab_version=" + string(version); "timestamp=" + string(ts)];
    writelines(man, 'stratum_results_manifest.txt');
end

function val = extract_kv(lines, key)
    val = "unknown"; prefix = string(key) + "="; lines = string(lines);
    for i = 1:length(lines)
        line_i = strtrim(lines(i));
        if startsWith(line_i, prefix), val = strtrim(extractAfter(line_i, prefix)); return; end
    end
end
