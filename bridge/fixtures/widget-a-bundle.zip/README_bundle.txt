Stratum Verification Bundle (run_id=widget-a, rev0->rev1)
Run `run_stratum_experiment` in MATLAB or use `stratum.m` in MATLAB Online.
